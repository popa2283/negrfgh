const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    username: String,
    avatar: String,
    balance: { type: Number, default: 100 },
    income: { type: Number, default: 0 },
    slaves: [{ type: String }] // Список ID рабов
});

module.exports = mongoose.model("User", userSchema);
