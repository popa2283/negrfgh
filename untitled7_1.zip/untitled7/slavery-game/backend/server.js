const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// 🔗 Подключение к MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/slavery-game', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('✅ Подключено к MongoDB'))
    .catch(err => console.log('❌ Ошибка подключения:', err));

// 📜 Модель раба
const Slave = mongoose.model('Slave', {
    name: String,
    photo: String,
    income: Number
});

// 📜 Модель пользователя
const User = mongoose.model('User', {
    name: String,
    master: String,
    balance: Number
});

// 🔥 Получение информации о текущем рабстве (заглушка для userId = 1)
app.get('/user', async (req, res) => {
    const user = await User.findOne({ _id: '1' });
    res.json(user);
});

// 🔥 Получение списка рабов
app.get('/slaves', async (req, res) => {
    const slaves = await Slave.find();
    res.json(slaves);
});
app.post("/buy", async (req, res) => {
    const { buyerId, slaveId } = req.body;

    const buyer = await User.findOne({ id: buyerId });
    const slave = await User.findOne({ id: slaveId });

    if (!buyer || !slave) {
        return res.status(400).json({ error: "Пользователь не найден" });
    }

    const price = Math.floor(slave.balance / 2);  // ✅ Цена = половина баланса раба

    if (buyer.balance < price) {
        return res.status(400).json({ error: "Недостаточно денег" });
    }

    // Перевод денег
    buyer.balance -= price;

    // Добавление раба в список
    buyer.slaves.push(slaveId);

    await buyer.save();

    res.json({ success: true, newOwner: buyer.username, price });
});
app.get("/leaderboard", async (req, res) => {
    try {
        const topUsers = await User.find().sort({ balance: -1 }).limit(100); // 🔥 ТОП-100 по балансу
        res.json(topUsers);
    } catch (error) {
        console.error("Ошибка загрузки рейтинга:", error);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});
app.get("/leaderboard", async (req, res) => {
    try {
        const topUsers = await User.find().sort({ balance: -1 }).limit(100);
        res.json(topUsers);
    } catch (error) {
        console.error("Ошибка загрузки рейтинга:", error);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});
app.get("/random-slaves", async (req, res) => {
    try {
        const slaves = await User.aggregate([{ $sample: { size: 50 } }]); // 🔥 50 случайных пользователей
        res.json(slaves);
    } catch (error) {
        console.error("Ошибка загрузки рабов:", error);
        res.status(500).json({ error: "Ошибка сервера" });
    }
});
// Запуск сервера
app.listen(3000, () => {
    console.log('🚀 Сервер запущен на порту 3000');
});
