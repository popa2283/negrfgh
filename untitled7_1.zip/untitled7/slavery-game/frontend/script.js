async function checkAuth() {
    const userData = localStorage.getItem("user");
    if (userData) {
        showUserInfo(JSON.parse(userData));
    }
}

function showUserInfo(user) {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("user-info").style.display = "block";
    document.getElementById("avatar").src = user.avatar;
    document.getElementById("nickname").textContent = `Привет, ${user.username}`;
    document.getElementById("balance").textContent = `Баланс: ${user.balance} ₽`;
    document.getElementById("income").textContent = `Доход в час: ${user.income} ₽`;
}
app.post("/auth", async (req, res) => {
    const { id, username, photo_url } = req.body;

    let user = await User.findOne({ id });

    if (!user) {
        user = new User({
            id,
            username,
            avatar: photo_url,
            balance: 50,  // ✅ Начальный баланс 50₽
            income: 0,
            slaves: []
        });
        await user.save();
    }

    res.json(user);
});
function logout() {
    localStorage.removeItem("user");
    location.reload();
}

document.addEventListener("DOMContentLoaded", checkAuth);
function showUserInfo(user) {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("user-info").style.display = "block";
    document.getElementById("avatar").src = user.avatar;
    document.getElementById("nickname").textContent = `Привет, ${user.username}`;
    document.getElementById("balance").textContent = `Баланс: ${user.balance} ₽`;
    document.getElementById("income").textContent = `Доход в час: ${user.income} ₽`;

    const refLink = `${window.location.origin}/?ref=${user.id}`;
    document.getElementById("ref-link").value = refLink;
}

function copyRef() {
    const input = document.getElementById("ref-link");
    input.select();
    document.execCommand("copy");
    alert("Ссылка скопирована!");
}
async function checkAuth() {
    const userData = localStorage.getItem("user");
    if (userData) {
        showUserInfo(JSON.parse(userData));
        return;
    }

    // Проверяем, есть ли в URL реферальный код
    const urlParams = new URLSearchParams(window.location.search);
    const refId = urlParams.get("ref");

    // Отправляем данные на сервер
    Telegram.WebApp.onEvent("auth", async (user) => {
        const response = await fetch("http://localhost:3000/auth", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...user, refId })
        });

        const data = await response.json();
        localStorage.setItem("user", JSON.stringify(data));
        showUserInfo(data);
    });
}
function showUserInfo(user) {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("user-info").style.display = "block";
    document.getElementById("avatar").src = user.avatar;
    document.getElementById("nickname").textContent = `Привет, ${user.username}`;
    document.getElementById("balance").textContent = `Баланс: ${user.balance} ₽`;
    document.getElementById("income").textContent = `Доход в час: ${user.income} ₽`;

    const refLink = `${window.location.origin}/?ref=${user.id}`;
    document.getElementById("ref-link").value = refLink;

    // Запрашиваем список рабов
    fetch(`http://localhost:3000/slaves?id=${user.id}`)
        .then(response => response.json())
        .then(data => showSlaves(data));
}

function showSlaves(slaves) {
    const list = document.getElementById("slaves-list");
    list.innerHTML = slaves.map(slave => `
        <div class="slave">
            <img src="${slave.avatar}" alt="Аватар">
            <p>${slave.username}</p>
            <p>Доход: 10 ₽/час</p>
        </div>
    `).join("");
}
function updateBalance(userId) {
    fetch(`http://localhost:3000/user?id=${userId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("balance").textContent = `Баланс: ${data.balance} ₽`;
        });
}

// Запускаем авто-обновление баланса
setInterval(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
        updateBalance(user.id);
    }
}, 10000);
async function loadLeaderboard() {
    const response = await fetch("http://localhost:3000/leaderboard");
    const data = await response.json();

    const richestList = document.getElementById("richest-list");
    richestList.innerHTML = data.richest.map(user => `
        <li>
            <img src="${user.avatar}" alt="Аватар">
            ${user.username} — 💰 ${user.balance} ₽
        </li>
    `).join("");

    const ownersList = document.getElementById("owners-list");
    ownersList.innerHTML = data.biggestOwners.map(user => `
        <li>
            <img src="${user.avatar}" alt="Аватар">
            ${user.username} — 🔗 ${user.slaves} рабов
        </li>
    `).join("");
}

// Загружаем рейтинг при старте
document.addEventListener("DOMContentLoaded", loadLeaderboard);
function showSlaves(slaves, userId) {
    const list = document.getElementById("slaves-list");
    list.innerHTML = slaves.map(slave => `
        <div class="slave">
            <img src="${slave.avatar}" alt="Аватар">
            <p>${slave.username}</p>
            <p>Доход: 10 ₽/час</p>
            <button onclick="sellSlave('${userId}', '${slave.id}')">Продать (${Math.floor(slave.balance / 2)} ₽)</button>
        </div>
    `).join("");
}

async function sellSlave(ownerId, slaveId) {
    const response = await fetch("http://localhost:3000/sell", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ownerId, slaveId })
    });

    const data = await response.json();
    if (data.success) {
        alert(`Вы продали раба за ${data.price} ₽`);
        location.reload();
    } else {
        alert("Ошибка: " + data.error);
    }
}
async function loadMarket(userId) {
    const response = await fetch("http://localhost:3000/leaderboard");
    const data = await response.json();

    const market = document.getElementById("market");
    market.innerHTML = data.biggestOwners.flatMap(owner =>
        owner.slaves.map(slaveId => `
            <div class="slave">
                <p>${owner.username} продаёт раба ID ${slaveId}</p>
                <button onclick="buySlave('${userId}', '${slaveId}')">Купить</button>
            </div>
        `)
    ).join("");
}

document.querySelectorAll(".buy-button").forEach(button => {
    button.addEventListener("click", async function () {
        const price = parseInt(this.getAttribute("data-price"));
        const slaveId = this.getAttribute("data-id");

        let userData = JSON.parse(localStorage.getItem("user"));

        if (userData.balance >= price) {
            try {
                const response = await fetch("http://localhost:3000/buy", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ buyerId: userData.id, slaveId })
                });

                const data = await response.json();
                if (data.success) {
                    // Обновляем баланс и список рабов в localStorage
                    userData.balance -= price;
                    userData.slaves.push(slaveId);
                    localStorage.setItem("user", JSON.stringify(userData));

                    // Обновляем баланс на странице
                    updateGlobalBalance();

                    // Обновляем список рабов в профиле
                    updateSlavesList();

                    this.textContent = "Куплено";
                    this.disabled = true;
                } else {
                    alert("Ошибка: " + data.error);
                }
            } catch (error) {
                console.error("Ошибка покупки:", error);
            }
        } else {
            alert("Недостаточно средств!");
        }
    });
});
async function updateSlavesList() {
    const userData = JSON.parse(localStorage.getItem("user"));
    if (!userData) return;

    try {
        const response = await fetch(`http://localhost:3000/slaves?id=${userData.id}`);
        const slaves = await response.json();

        const list = document.getElementById("slaves-list");
        list.innerHTML = slaves.map(slave => `
            <div class="slave">
                <img src="${slave.avatar}" alt="Аватар">
                <p>${slave.username}</p>
                <p>Доход: 10 ₽/час</p>
            </div>
        `).join("");
    } catch (error) {
        console.error("Ошибка загрузки рабов:", error);
    }
}
async function updateSlavesList() {
    const userData = JSON.parse(localStorage.getItem("user"));
    if (!userData) return;

    try {
        const response = await fetch(`http://localhost:3000/slaves?id=${userData.id}`);
        const slaves = await response.json();

        const list = document.getElementById("slaves-list");
        let totalIncome = 0; // 🔥 Считаем суммарный доход

        list.innerHTML = slaves.map(slave => {
            totalIncome += slave.income; // ✅ Добавляем доход каждого раба
            return `
                <div class="slave">
                    <img src="${slave.avatar}" alt="Аватар">
                    <p>${slave.username}</p>
                    <p>Доход: ${slave.income} ₽/мин</p>
                </div>
            `;
        }).join("");

        // 🔥 Обновляем доход в профиле
        document.getElementById("total-income").textContent = `Общий доход: ${totalIncome} ₽/мин`;

    } catch (error) {
        console.error("Ошибка загрузки рабов:", error);
    }
}
document.addEventListener("DOMContentLoaded", async () => {
    try {
        const response = await fetch("http://localhost:3000/random-slaves");
        const slaves = await response.json();
        const store = document.getElementById("store");

        store.innerHTML = ""; // Очищаем перед добавлением

        slaves.forEach(slave => {
            const price = Math.floor(slave.balance / 2); // ✅ Цена = 50% от баланса

            const slaveCard = document.createElement("div");
            slaveCard.classList.add("slave-card");

            slaveCard.innerHTML = `
                <img src="${slave.avatar}" alt="Аватар">
                <h3>${slave.username}</h3>
                <p>💰 Доход: ${slave.income} ₽/мин</p>
                <p class="price">💵 Цена: ${price} ₽</p>
                <button class="buy-button" data-id="${slave.id}" data-price="${price}">Купить</button>
            `;

            store.appendChild(slaveCard);
        });

    } catch (error) {
        console.error("Ошибка загрузки рабов:", error);
    }
});
document.addEventListener("DOMContentLoaded", () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
        loadMarket(user.id);
    }
});
async function loadLeaderboard() {
    const response = await fetch("http://localhost:3000/leaderboard");
    const data = await response.json();

    const richestList = document.getElementById("richest-list");
    richestList.innerHTML = data.richest.map(user => `
        <div class="leaderboard-item">
            <img src="${user.avatar}" alt="Аватар">
            <span>${user.username}</span>
            <span>💰 ${user.balance} ₽</span>
        </div>
    `).join("");

    const ownersList = document.getElementById("owners-list");
    ownersList.innerHTML = data.biggestOwners.map(user => `
        <div class="leaderboard-item">
            <img src="${user.avatar}" alt="Аватар">
            <span>${user.username}</span>
            <span>🔗 ${user.slaves} рабов</span>
        </div>
    `).join("");
}

document.addEventListener("DOMContentLoaded", loadLeaderboard);
function showSlaves(slaves, userId) {
    const list = document.getElementById("slaves-list");
    list.innerHTML = slaves.map(slave => `
        <div class="slave">
            <img src="${slave.avatar}" alt="Аватар">
            <span>${slave.username}</span>
            <span>💰 10 ₽/час</span>
            <button onclick="sellSlave('${userId}', '${slave.id}')">Продать (${Math.floor(slave.balance / 2)} ₽)</button>
        </div>
    `).join("");
}
document.addEventListener("DOMContentLoaded", () => {
    const openButtons = document.querySelectorAll(".open-modal");
    const closeButtons = document.querySelectorAll(".close-modal");
    const modals = document.querySelectorAll(".modal");

    // Открытие модального окна
    openButtons.forEach(button => {
        button.addEventListener("click", () => {
            const modalId = button.getAttribute("data-modal");
            document.getElementById(modalId).style.display = "block";
        });
    });

    // Закрытие модального окна
    closeButtons.forEach(button => {
        button.addEventListener("click", () => {
            button.parentElement.parentElement.style.display = "none";
        });
    });

    // Закрытие при клике вне окна
    modals.forEach(modal => {
        modal.addEventListener("click", (event) => {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });
    });

    // 🔥 Загружаем рейтинг (заглушка, нужно подключить бэкенд)
    fetch('/api/rating')
        .then(response => response.json())
        .then(data => {
            const ratingList = document.getElementById("ratingList");
            ratingList.innerHTML = "";
            data.forEach(player => {
                const li = document.createElement("li");
                li.textContent = `${player.name} - ${player.score} очков`;
                ratingList.appendChild(li);
            });
        });

    // 🔥 Загружаем топ-игроков (заглушка, нужно подключить бэкенд)
    fetch('/api/top-players')
        .then(response => response.json())
        .then(data => {
            const topList = document.getElementById("topPlayersList");
            topList.innerHTML = "";
            data.forEach(player => {
                const li = document.createElement("li");
                li.textContent = `${player.name} - ${player.slaves} рабов`;
                topList.appendChild(li);
            });
        });

    // 🛒 Покупка раба (заглушка, нужен бэкенд)
    document.getElementById("buySlave").addEventListener("click", () => {
        fetch('/api/buy-slave', { method: 'POST' })
            .then(response => response.json())
            .then(data => alert(data.message));
    });
});
async function updateGlobalBalance() {
    const userData = JSON.parse(localStorage.getItem("user"));
    if (!userData) return;

    try {
        const response = await fetch(`http://localhost:3000/user?id=${userData.id}`);
        const data = await response.json();

        userData.balance = data.balance;
        localStorage.setItem("user", JSON.stringify(userData));

        // Обновляем баланс на всех страницах
        const balanceElements = document.querySelectorAll(".balance-value");
        balanceElements.forEach(el => el.textContent = `${data.balance} ₽`);
    } catch (error) {
        console.error("Ошибка обновления баланса:", error);
    }
}

// Обновляем баланс при загрузке магазина
document.addEventListener("DOMContentLoaded", updateGlobalBalance);

// Переход по разделам
function goTo(section) {
    alert("Переход на " + section);
}
document.addEventListener("DOMContentLoaded", () => {
    const openButtons = document.querySelectorAll(".open-modal");
    const closeButtons = document.querySelectorAll(".close-modal");
    const modals = document.querySelectorAll(".modal");

    // Открытие модального окна
    openButtons.forEach(button => {
        button.addEventListener("click", () => {
            const modalId = button.getAttribute("data-modal");
            document.getElementById(modalId).style.display = "block";
        });
    });

    // Закрытие модального окна
    closeButtons.forEach(button => {
        button.addEventListener("click", () => {
            button.parentElement.parentElement.style.display = "none";
        });
    });

    // Закрытие при клике вне окна
    modals.forEach(modal => {
        modal.addEventListener("click", (event) => {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });
    });

    // 🔥 Загружаем рейтинг (заглушка, нужно подключить бэкенд)
    fetch('/api/rating')
        .then(response => response.json())
        .then(data => {
            const ratingList = document.getElementById("ratingList");
            ratingList.innerHTML = "";
            data.forEach(player => {
                const li = document.createElement("li");
                li.textContent = `${player.name} - ${player.score} очков`;
                ratingList.appendChild(li);
            });
        });

    // 🔥 Загружаем топ-игроков (заглушка, нужно подключить бэкенд)
    fetch('/api/top-players')
        .then(response => response.json())
        .then(data => {
            const topList = document.getElementById("topPlayersList");
            topList.innerHTML = "";
            data.forEach(player => {
                const li = document.createElement("li");
                li.textContent = `${player.name} - ${player.slaves} рабов`;
                topList.appendChild(li);
            });
        });

    // 🛒 Покупка раба (заглушка, нужен бэкенд)
    document.getElementById("buySlave").addEventListener("click", () => {
        fetch('/api/buy-slave', { method: 'POST' })
            .then(response => response.json())
            .then(data => alert(data.message));
    });
});
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // 🔥 Загружаем информацию о текущем рабстве
        const userRes = await fetch('http://localhost:3000/user');
        const user = await userRes.json();
        document.getElementById('slave-info').innerHTML = `Вы в рабстве у <strong>${user.master}</strong>`;

        // 🔥 Загружаем список рабов
        const slavesRes = await fetch('http://localhost:3000/slaves');
        const slaves = await slavesRes.json();
        const slavesList = document.getElementById('slaves-list');

        slavesList.innerHTML = '';
        slaves.forEach(slave => {
            const slaveCard = document.createElement('div');
            slaveCard.classList.add('slave-card');
            slaveCard.innerHTML = `
                <img src="${slave.photo}" alt="${slave.name}">
                <div class="info">
                    <p class="name">${slave.name}</p>
                    <p class="income">${slave.income} 💰/мин</p>
                </div>
            `;
            slavesList.appendChild(slaveCard);
        });
    } catch (error) {
        console.error('Ошибка загрузки:', error);
    }
});
function shareLink() {
    const shareUrl = window.location.href; // Получаем текущий URL

    // Проверяем, поддерживается ли Web Share API (для мобильных устройств)
    if (navigator.share) {
        navigator.share({
            title: "Стань моим рабом!",
            text: "Переходи по ссылке и присоединяйся!",
            url: shareUrl
        }).then(() => {
            console.log("Ссылка успешно отправлена!");
        }).catch((error) => {
            console.error("Ошибка при отправке: ", error);
        });
    } else {
        // Если Web Share API недоступен — копируем ссылку в буфер обмена
        navigator.clipboard.writeText(shareUrl).then(() => {
            const message = document.getElementById("copy-message");
            message.classList.remove("hidden"); // Показываем сообщение
            setTimeout(() => message.classList.add("hidden"), 2000); // Скрываем через 2 сек
        }).catch((err) => {
            console.error("Ошибка копирования: ", err);
        });
    }
}
document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("search");
    const slavesList = document.getElementById("slaves-list"); // Контейнер со списком рабов

    searchInput.addEventListener("input", function () {
        const query = searchInput.value.trim().toLowerCase(); // Приводим к нижнему регистру
        const slaves = document.querySelectorAll(".slave-item"); // Все карточки рабов

        slaves.forEach(slave => {
            const name = slave.querySelector(".slave-name").textContent.toLowerCase();
            if (name.includes(query)) {
                slave.style.display = "block"; // Показываем, если подходит
            } else {
                slave.style.display = "none"; // Скрываем, если нет
            }
        });
    });
});
async function updateGlobalBalance() {
    const userData = JSON.parse(localStorage.getItem("user"));
    if (!userData) return;

    try {
        const response = await fetch(`http://localhost:3000/user?id=${userData.id}`);
        const data = await response.json();

        userData.balance = data.balance;
        localStorage.setItem("user", JSON.stringify(userData));

        // Обновляем баланс на всех страницах
        const balanceElements = document.querySelectorAll(".balance-value");
        balanceElements.forEach(el => el.textContent = `${data.balance} ₽`);
    } catch (error) {
        console.error("Ошибка обновления баланса:", error);
    }
}

// Запускаем авто-обновление баланса
setInterval(updateGlobalBalance, 10000);

// Обновляем баланс при загрузке страницы
document.addEventListener("DOMContentLoaded", updateGlobalBalance);
